<?php

class Calendarcontroller
{
    private $registry;
    
    public function __construct(Registry $registry)
    {
        $this->registry=$registry;
        $urlBits=$this->registry->getObject('url')->getURLBits();
        if(isset($urlBits[1]))
        {
            switch($urlBits[1])
            {
                case 'test':
                    $this->testOutput();
                    break;
                case 'birthdays':
                    $this->birthdays();
                    break;
            }
        }
            
    }
    
    private function testOutput()
    {
        require_once(FRAMEWORK_PATH.'lib/calendar/calendar.class.php');
        $m=date('m');
        $y=date('y');
        if(isset($_GET['month']))
        {
            $m=intval($_GET['month']);
            if($m<1||$m>12)
            {
                $m=date('m');
            }
        }
        if(isset($_GET['year']))
        {
            $y=intval($_GET['year']);
        }
        $calendar= new Calendar('',$m,$y);
        $nm=$calendar->getNextMonth()->getMonth();
        $pm=$calendar->getPreviousMonth()->getMonth();
        $ny=$calendar->getNextMonth()->getYear();
        $py=$calendar->getPreviousMonth()->getYear();
        
        $this->registry->getObject('template')->getPage()->addTag('py',$py);
        $this->registry->getObject('template')->getPage()->addTag('ny',$ny);
        $this->registry->getObject('template')->getPage()->addTag('pm',$pm);
        $this->registry->getObject('template')->getPage()->addTag('nm',$nm);
        
        $this->registry->getObject('template')->getPage()->addTag('month_name',$calendar->getMonthName());
        $this->registry->getObject('template')->getPage()->addTag('the_year',$calendar->getYear());
        
        $calendar->setStartDay(0);
        $calendar->buildMonth();
        $this->registry->getObject('template')->dataToTags($calendar->getDates(),'cal_0_dates_');
        $this->registry->getObject('template')->dataToTags($calendar->getDateData(),'cal_0_datedata_');
        $this->registry->getObject('template')->dataToTags($calendar->getDateStyles(),'cal_0_datestyles_');
        $this->registry->getObject('template')->dataToTags($calendar->getDaysInOrder(),'cal_0_day_');
        $this->registry->getObject('template')->buildFromTemplates('test-calendar.tpl.php');
           
           
        
    }
    
    private function birthdays()
    {
        require_once(FRAMEWORK_PATH.'lib/calendar/calendar.class.php');
        $m=date('m');
        $y=date('y');
        if(isset($_GET['month']))
        {
            $m=intval($_GET['month']);
            if($m>12 || $m<1)
            {
                $m=date('m');
            }
        }
        if(isset($_GET['year']))
        {
            $y=intval($_GET['year']);
        }
        $calendar=new Calendar('',$m,$y);
        $ny=$calendar->getNextMonth()->getYear();
        $nm=$calendar->getNextMonth()->getMonth();
        $py=$calendar->getPreviousMonth()->getYear();
        $pm=$calendar->getPreviousMonth()->getMonth();
        
        $this->registry->getObject('template')->getPage()->addTag('pm',$pm);
        $this->registry->getObject('template')->getPage()->addTag('py',$py);
        $this->registry->getObject('template')->getPage()->addTag('nm',$nm);
        $this->registry->getObject('template')->getPage()->addTag('ny',$ny);
        
        $this->registry->getObject('template')->getPage()->addTag('the_year',$calendar->getYear());
        $this->registry->getObject('template')->getPage()->addTag('month_name',$calendar->getMonthName());
        
        $calendar->setStartDay(0);
        $calendar->buildMonth();
        
        
        require_once(FRAMEWORK_PATH.'models/relationships.php');
        $relationships=new Relationships($this->registry);
        $ids=$relationships->getIDsByUser($this->registry->getObject('authenticate')->getUser()->getUserID());
        $sql="select date_format(p.user_dob,'%d') as profile_dob, p.ID as profile_ID, p.fname as profile_fname, p.lname as profile_lname,
            ((year(curdate()))-(date_format(p.user_dob,'%Y'))) as profile_new_age from profile p where p.ID in (".$ids.") and p.user_dob like '%-{$m}-%'";
        $this->registry->getObject('db')->executeQuery($sql);
        
        $dates=array();
        $data=array();
        if($this->registry->getObject('db')->numRows()>0)
        {
            while($row=$this->registry->getObject('db')->getRows())
            {
                $dates[]=$row['profile_dob'];
                $data[intval($row['profile_dob'])]="<br/>".$row['profile_fname']." ".$row['profile_lname']."(".$row['profile_new_age'].")<br/>";
            }
        }
        $calendar->setDaysWithEvents($dates);
        $calendar->setData($data);
        $calendar->buildMonth();
        $this->registry->getObject('template')->dataToTags($calendar->getDates(),'cal_0_dates_');
        $this->registry->getObject('template')->dataToTags($calendar->getDaysInOrder(),'cal_0_day_');
        $this->registry->getObject('template')->dataToTags($calendar->getDateStyles(),'cal_0_datestyles_');
        $this->registry->getObject('template')->dataToTags($calendar->getDateData(),'cal_0_datedata_');
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','bd-calendar.tpl.php','footer.tpl.php');
    }
}
?>