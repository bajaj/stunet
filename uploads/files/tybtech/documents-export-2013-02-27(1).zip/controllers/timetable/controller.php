<?php


class Timetablecontroller
{


public function __construct( Registry $registry, $directCall=true )
	{
		$this->registry = $registry;
		if( $this->registry->getObject('authenticate')->isLoggedIn() )
		{
			if($this->isteacher())
			{
				$urlBits = $this->registry->getObject('url')->getURLBits();
				if( isset( $urlBits[1] ) )
			   {
				  switch( $urlBits[1] )
				  {
					case 'create':
					$this->create($urlBits[2],intval( $urlBits[3] ));   // group_id 
					break;

					case 'edit':
					$this->edit($urlBits[2],intval( $urlBits[3] ));
					break;
					
					case 'view':
					$this->view($urlBits[2],intval( $urlBits[3] ));
					break;
					
					default:
					$this->view($urlBits[2],intval( $urlBits[3] ));
				  }	
			    }
			}
			else
			{
			// student part
			$urlBits = $this->registry->getObject('url')->getURLBits();
			  if( isset( $urlBits[1] ) )
			   {
				  switch( $urlBits[1] )
				  {
					case 'view':
					$this->view($urlBits[2],intval( $urlBits[3] ));  
					break;
					
					default:
					$this->view($urlBits[2],intval( $urlBits[3] ));
				  } 	
				}
			}
		}
		else
		{
		$this->registry->errorPage( 'Access denied', 'please login to view this page');
		
		}
	}
	

private function create($type,$grp_id)
{
	if(!($this->group_valid($grp_id)))
	{
	$this->registry->errorPage( 'Not A group ', 'This Group does not exist');	
	}
	else
	{
     	if($this->isteacher_group($grp_id))
		{
			if( isset( $_POST ) && count( $_POST ) > 0 )
			{
			require_once( FRAMEWORK_PATH . 'models/timetable.php' );
			$time = new Timetable( $this->registry,0);


			$time->setgroup_id($grp_id);
			
			$time->setrow($_POST['row1'],1);$time->setrow($_POST['row2'],2);$time->setrow($_POST['row3'],3);
			$time->setrow($_POST['row4'],4);$time->setrow($_POST['row5'],5);$time->setrow($_POST['row6'],6);
			$time->setrow($_POST['row7'],7);$time->setrow($_POST['row8'],8);$time->setrow($_POST['row9'],9);
			$time->setrow($_POST['row10'],10);
			
			$time->setnote($_POST['note']);
			$time->settype($type);
			$time->save(intval(0));
			
			$this->registry->errorPage( 'Successfull', 'Time Table has been succesfully created');
			

				

			

		// send email for evaluation details write code in save

		/*	$url = $this->registry->getObject('url')->buildURL( array('timetable'), '', false );
			$this->registry->redirectUser( $url, 'Evaluation Successfull', 'You have successfully entered the marks of your student');
			
			*/

			}
			else
			{
				if($this->table_check($type,$grp_id))  // table does not exists	if true then create
				{
				 require_once( FRAMEWORK_PATH . 'models/timetable.php' );
				$time = new Timetable( $this->registry,0);

				$this->registry->getObject('template')->buildFromTemplates('header.tpl.php', 'timetable/create.tpl.php', 'footer.tpl.php');


				$this->registry->getObject('template')->getPage()->addTag('group_info',array('SQL',$time->getgroupinfo($grp_id)));
				$this->registry->getObject('template')->getPage()->addTag('type',$type);
				
				//$this->registry->getObject('template')->getPage()->addTag('evaluation',array('SQL',$eval->getmystudents($grp_id)));
				}
				else
				{
				$this->registry->errorPage( 'Time-Table already exists', 'There can be only one timetable for a Class.Please view that <div id="errorlink"><a href=\'view/'.$type.'/'.$grp_id.'
				   \'>timetable.</a></div>');
				}
			}
		}	
		else
		{
		  $this->registry->errorPage( 'Not group Member', 'please become member of this group to create timetable');
		}
	}

}

private function view($type,$grp_id)
{
   if(!($this->group_valid($grp_id)))
	{
	$this->registry->errorPage( 'Not A group ', 'This Group does not exist');	
	}
	else
	{
	
		if($this->isteacher_group($grp_id)) //  teacher or student belongs to group
		{
			if($type=='class' OR $type=='exam')
			{
		
				if($this->table_check($type,$grp_id))     // check if that timetable exists
				{
				$this->registry->errorPage( 'TimeTable Does not Exists ', 'There is no such timetable.First Create that Timetable.</br>Only teacher can create a timetable');		
				}
				else
				{
				require_once( FRAMEWORK_PATH . 'models/timetable.php' );
					$time = new Timetable( $this->registry,0);
		
				if($this->isteacher())
				{
				$this->registry->getObject('template')->buildFromTemplates('header.tpl.php', 'timetable/view_teacher.tpl.php', 'footer.tpl.php');
				}
				else
				{
				$this->registry->getObject('template')->buildFromTemplates('header.tpl.php', 'timetable/view.tpl.php', 'footer.tpl.php');
				}	
			 $this->registry->getObject('template')->getPage()->addTag('group_info',array('SQL',$time->getgroupinfo($grp_id)));
			 $this->registry->getObject('template')->getPage()->addTag('type',$type);
			  $this->registry->getObject('template')->getPage()->addTag('time',array('SQL',$time->gettable($type,$grp_id)));
			  $this->registry->getObject('template')->getPage()->addTag('note',array('SQL',$time->getnote($type,$grp_id)));
			  }
			}
			else
			{
			$this->registry->errorPage( 'TimeTable Does not Exists ', 'There is no such timetable.First Create that Timetable.</br>Only teacher can create a timetable');
			}
			
		}
		else
		{
		$this->registry->errorPage( 'You are not a member ', 'only member of this group can see the timetable');	
		}
	

	}

}	
	
	
private function edit($type,$grp_id)
{
   if(!($this->group_valid($grp_id)))
	{
	$this->registry->errorPage( 'Not A group ', 'This Group does not exist');	
	}
	else
	{
	
		if($this->isteacher_group($grp_id)) //  teacher or student belongs to group
		{
			if($type=='class' OR $type=='exam')
			{
		
				if($this->table_check($type,$grp_id))     // check if that timetable exists
				{
				$this->registry->errorPage( 'TimeTable Does not Exists ', 'There is no such timetable.First Create that Timetable.</br>Only teacher can create a timetable');		
				}
				else
				{
				require_once( FRAMEWORK_PATH . 'models/timetable.php' );
					$time = new Timetable( $this->registry,0);
		
					if($this->isteacher())         // edit it
					{	
						if( isset( $_POST ) && count( $_POST ) > 0 )   // update timetable
						{
								$time->setgroup_id($grp_id);
								
								$time->setrow($_POST['row1'],1);$time->setrow($_POST['row2'],2);$time->setrow($_POST['row3'],3);
			$time->setrow($_POST['row4'],4);$time->setrow($_POST['row5'],5);$time->setrow($_POST['row6'],6);
			$time->setrow($_POST['row7'],7);$time->setrow($_POST['row8'],8);$time->setrow($_POST['row9'],9);
			$time->setrow($_POST['row10'],10);
								
								
			
							//	$time->seteditrow($_POST['row1']);
								
								/*$time->setrow($_POST['row1[1]']);$time->setrow($_POST['row1[2]']);
								$time->setrow($_POST['row1[3]']);$time->setrow($_POST['row1[4]']);$time->setrow($_POST['row1[5]']);
								$time->setrow($_POST['row1[6]']);$time->setrow($_POST['row1[7]']);$time->setrow($_POST['row1[8]']);
								$time->setrow($_POST['row1[9]']);*/
								
								$time->setnote($_POST['note']);
								$time->settype($type);
								
								$time->save(intval(1));   // 1 indicate that it is a update and not a creation of time table
								$this->registry->errorPage( 'Updated ', 'TimeTable is updated');				
						}
						
						else                                            // edit timttable      
						{
					
						$this->registry->getObject('template')->buildFromTemplates('header.tpl.php', 'timetable/edit.tpl.php', 'footer.tpl.php');
					
						$this->registry->getObject('template')->getPage()->addTag('group_info',array('SQL',$time->getgroupinfo($grp_id)));
						$this->registry->getObject('template')->getPage()->addTag('type',$type);
						$this->registry->getObject('template')->getPage()->addTag('time',array('SQL',$time->getedittable($type,$grp_id)));
						$this->registry->getObject('template')->getPage()->addTag('note',array('SQL',$time->getnote($type,$grp_id)));
						}
					}
					else
					{
				$this->registry->errorPage( 'Acess Denied ', 'Only Teachers can edit the timetable');
				
					}
				}
			}
			else
			{
			$this->registry->errorPage( 'TimeTable Does not Exists ', 'There is no such timetable.First Create that Timetable.</br>Only teacher can create a timetable');
			}	
		}
		
		else
			{
			$this->registry->errorPage( 'Access Denied ', 'You are not member of this group');
			}	
		
		
	}
	
}	
	
	
	
	
	
	
	
	
	
	

	
private function isteacher()
{
$my_id=$this->registry->getObject('authenticate')->getUser()->getUserID();

$sql="SELECT p.type FROM profile p WHERE p.ID=".$my_id;

$this->registry->getObject('db')->executeQuery( $sql );

$data = $this->registry->getObject('db')->getRows();

if($data['type']=="professor")
return true;
else
return false;

}

private function isteacher_group($grp_id)
{
$my_id=$this->registry->getObject('authenticate')->getUser()->getUserID();

$sql="SELECT gm.group FROM group_membership gm WHERE gm.user=".$my_id." AND gm.group=".$grp_id;
$this->registry->getObject('db')->executeQuery( $sql );

if($this->registry->getObject('db')->numRows() > 0)
return true ;
else
return false;

}

private function group_valid($grp_id)
{
$sql="SELECT g.ID FROM groups g WHERE g.ID=".$grp_id;
$this->registry->getObject('db')->executeQuery( $sql );

if($this->registry->getObject('db')->numRows() > 0)
return true ;
else
return false;
}


private function table_check($type,$grp_id)
{
$sql="SELECT * FROM table_check t WHERE t.group_id=".$grp_id." AND t.".$type."=1";

$this->registry->getObject('db')->executeQuery( $sql );

if($this->registry->getObject('db')->numRows() > 0)  // time table already exists
return false ;
else
return true;

}


}
	
?>	