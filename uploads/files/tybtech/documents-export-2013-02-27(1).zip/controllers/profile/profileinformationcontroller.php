<?php

class Profileinformationcontroller{
    private $registry;
    
    public function __construct(Registry $registry,$user){
        $this->registry=$registry;
        $urlBits=$this->registry->getObject('url')->getURLBits();
        if(isset($urlBits[2])){
            switch($urlBits[2]){
                case 'edit':
                    $this->editProfile();
                    break;
                default:
                    $this->viewProfile($user);
                    break;
            }
        }
        else{
        $this->viewProfile($user);}
    }
    
    private function viewProfile($user){
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','profile/information/view.tpl.php','footer.tpl.php');
        require_once(FRAMEWORK_PATH.'models/profile.php');
        $profile= new Profile($this->registry,$user);
        $profile->toTags('p_');
        if(isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']==$this->registry->getSetting('siteurl').'profile/view/edit/')
            $this->registry->getObject('template')->getPage()->addTag('error','<center><p><strong>Your profile has been successfully edited!</strong></p></center><br/>');
        else
        $this->registry->getObject('template')->getPage()->addTag('error','');
    }
    
    private function editProfile(){
        if($this->registry->getObject('authenticate')->isLoggedIn()){
            $user=$this->registry->getObject('authenticate')->getUser()->getUserID();
            if(isset($_POST)&& count($_POST)>0){
                $profile=new Profile($this->registry,$user);
                $profile->setBio($this->registry->getObject('db')->sanitizeData($_POST['bio']));
                $profile->setFName($this->registry->getObject('db')->sanitizeData($_POST['fname']));
                $profile->setLname($this->registry->getObject('db')->sanitizeData($_POST['lname']));
                $profile->setInfo1($this->registry->getObject('db')->sanitizeData($_POST['info1']));
                $profile->setInfo2($this->registry->getObject('db')->sanitizeData($_POST['info2']));
                $profile->setCollege($this->registry->getObject('db')->sanitizeData($_POST['college']));
                $profile->setDOB($this->registry->getObject('db')->sanitizeData($_POST['dob_year']).'-'.$this->registry->getObject('db')->sanitizeData($_POST['dob_month']).'-'.$this->registry->getObject('db')->sanitizeData($_POST['dob_day']));
                $profile->setGender($this->registry->getObject('db')->sanitizeData($_POST['gender']));
                if(isset($_FILES['profile_picture'])){
                    require_once(FRAMEWORK_PATH.'lib/images/imagemanager.class.php');
                    $imagemanager=new Imagemanager();
                    $im=$imagemanager->loadFromPost('profile_picture',$this->registry->getSetting('uploads_path').'profile/',time());
                    if($im==true){
                        $imagemanager->resize(200,200);
                        $imagemanager->save(FRAMEWORK_PATH.$this->registry->getSetting('uploads_path').'profile/'.$imagemanager->getName());
                        $profile->setPhoto($imagemanager->getName());
                }
                }
                $profile->save();
                header('Location: '.$this->registry->getSetting('siteurl').'profile/view');
               
                //$this->registry->redirectUser($this->registry->getSetting('siteurl').'profile/view','Profile edited!','Your profile has been edited successfully');
            }
            else{
                $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','profile/information/edit.tpl.php','footer.tpl.php');
                require_once(FRAMEWORK_PATH.'models/profile.php');
                $profile=new Profile($this->registry,$user);
                $profile->toTags('p_');
                $dob=$profile->getDOB();
                $gender=($profile->getGender()=='Male')?0:1;
                $dob=explode('-',$dob);
                $script="";
          $script.="<script type='text/javascript'>";
          $script.="document.getElementById('gender').selectedIndex=".$gender.';';
          $script.="document.getElementById('dob_day').selectedIndex=".intval($dob[2]).';';
          $script.="document.getElementById('dob_month').selectedIndex=".intval($dob[1]).';';
          $script.="document.getElementById('dob_year').selectedIndex=".(2013-$dob[0]+1).';';
          $script.="</script>";
          $this->registry->getObject('template')->getPage()->addTag('script',$script);
            }
        }
        else{
            $this->registry->errorPage('Not logged in','You must be logged in to edit your profile!');
        }
    }
    
}
?>
