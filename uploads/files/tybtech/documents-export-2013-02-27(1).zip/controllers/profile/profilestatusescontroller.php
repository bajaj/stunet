<?php

class Profilestatusescontroller{
    private $registry;
    
    public function __construct(Registry $registry,$user){
        $this->registry=$registry;
        $this->listRecentStatuses($user);
    }
    
    private function listRecentStatuses($user){
        //load the template
        if($user==$this->registry->getObject('authenticate')->getUser()->getUserID())
            $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','profile/statuses/mine.tpl.php','footer.tpl.php');
        else
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','profile/statuses/list.tpl.php','footer.tpl.php');
        
        //Display message box
        if($this->registry->getObject('authenticate')->isLoggedIn()){
            if(isset($_POST)&& count($_POST)>0){
                $this->addStatus($user);
            }
           
            $loggedInUser=$this->registry->getObject('authenticate')->getUser()->getUserID();
            if($loggedInUser==$user){
                $this->registry->getObject('template')->addTemplateBit('status_update','profile/statuses/update.tpl.php');
            }
            else{
                require_once(FRAMEWORK_PATH.'models/relationships.php');
                $relationships=new Relationships($this->registry);
                $network=$relationships->getNetwork($user);
                if(in_array($loggedInUser,$network)){
                    $this->registry->getObject('template')->addTemplateBit('status_update','profile/statuses/post.tpl.php');
                }
                else{
                    $this->registry->getObject('template')->addTemplateBit('status_update','profile/statuses/cantpost.tpl.php');
                }
            }
        }
        else{
            $this->registry->getObject('template')->addTemplateBit('status_update','profile/statuses/cantpost.tpl.php');
        }
        
        
        
        $updates=array();
        $ids=array();
        
        //get updates from the database
        
        //
        /*$sql="select t.type_name,t.type_reference, s.*,UNIX_TIMESTAMP(s.posted) as timestamp,pa.fname as poster_fname, pa.lname as poster_lname, i.image, v.video_id,
        l.url, l.description from profile p, statuses s left join statuses_images i on s.ID=i.ID left join
        statuses_videos v on s.ID=v.ID left join statuses_links l on s.ID=l.ID, status_types t, profile pa where
            s.poster=pa.ID and p.ID= s.profile and s.type=t.ID and p.ID={$user} order by s.ID desc limit 20";*/
              $network=array();
        require_once(FRAMEWORK_PATH.'models/relationships.php');
        $relationships=new Relationships($this->registry);
        $network=$relationships->getNetwork($user);//Get the ID of all users the logged in user is connected to
        $network[]=0;
        $network=implode(',',$network);
        
        $sql="select s.*, t.type_name, t.type_reference,UNIX_TIMESTAMP(s.posted) as timestamp, p.fname as poster_fname, p.lname as poster_lname,i.image, v.video_id,
        l.url, l.description, r.fname as profile_fname, r.lname as profile_lname from profile p, profile r, statuses s left join statuses_images i on s.ID=i.ID left join
        statuses_videos v on s.ID=v.ID left join statuses_links l on s.ID=l.ID, status_types t where s.type=t.ID and
             p.ID = s.poster and r.ID=s.profile and (r.ID={$user} or p.ID={$user} or r.ID in ({$network}) or p.ID in ({$network})) 
             order by s.ID desc limit 20";
        $this->registry->getObject('db')->executeQuery($sql);
        if($this->registry->getObject('db')->numRows()>0){
            //populate the ID and updates array
            while($row=$this->registry->getObject('db')->getRows()){
                $row['friendly_time']=$this->getFriendlyTime($row['timestamp']);
                $updates[]=$row;
                $ids[$row['ID']]=$row;
            }
        }
        
        $post_ids=array_keys($ids);
        
        if(count($post_ids)>0){//check where there are status updates
            $post_ids=implode(',',$post_ids);//form a string from the array elements seperated by ',' 
            $pids=array_keys($ids);
            foreach($pids as $id){//blank out comments by default
                $blank=array();
                $blank=$this->registry->getObject('db')->cacheData($blank);
                $this->registry->getObject('template')->getPage()->addPPTag('comments-'.$id,array('DATA',$blank));
            }
        
        
        $sql="select p.fname as commentor_fname,p.lname as commentor_lname, UNIX_TIMESTAMP(c.created) as timestamp, c.profile_post, c.comment from profile p, comments c where 
            c.approved=1 and p.ID = c.creator and c.profile_post in ({$post_ids})";
            $this->registry->getObject('db')->executeQuery($sql);
            if($this->registry->getObject('db')->numRows()>0)//If there are any comments for all profile_posts combined
            {
                $comments=array();//The array that will hold the comments as values and the corresponding profile posts as key
                while($comment=$this->registry->getObject('db')->getRows())
                    {
                    $comment['comment_friendly_time']=$this->getFriendlyTime('timestamp');
                        if(in_array($comment['profile_post'],$comments)){
                        $comments[$comment['profile_post']][]=$comment;
                        }
                        else
                        {
                        $comments[$comment['profile_post']]=array();
                        $comments[$comment['profile_post']][]=$comment;
                         }
                    }
                foreach($comments as $post=>$commentList)
                {
                    $cache=$this->registry->getObject('db')->cacheData($commentList);
                    $this->registry->getObject('template')->getPage()->addPPTag('comments-'.$post,array('DATA',$cache));
               }
            }    }
        
        
         $cache=$this->registry->getObject('db')->cacheData($updates);
        
        $this->registry->getObject('template')->getPage()->addTag('updates',array('DATA',$cache));
        foreach($ids as $id=>$data)
        {
            $this->registry->getObject('template')->addTemplateBit('update-'.$id,'profile/updates/'.$data['type_reference'].'.tpl.php',$data);
        }
     
}

    private function addStatus($user){
        $loggedInUser=$this->registry->getObject('authenticate')->getUser()->getUserID();
        
        if($loggedInUser==$user){
            require_once(FRAMEWORK_PATH.'models/status.php');
            if(isset($_POST['status_type']) && $_POST['status_type']!='update')
            {
              if($_POST['status_type']=='image')
              {
                  require_once(FRAMEWORK_PATH.'models/imagestatus.php');
                  $status=new Imagestatus($this->registry,0);
                  $status->processImage('image_file');
              }
              elseif($_POST['status_type']=='video')
              {
                  require_once(FRAMEWORK_PATH.'models/videostatus.php');
                  $status=new Videostatus($this->registry,0);
                  $status->setVideoIdFromURL($_POST['video_url']);
              }
              elseif($_POST['status_type']=='link')
              {
                  require_once(FRAMEWORK_PATH.'models/linkstatus.php');
                  $status=new Linkstatus($this->registry,0);
                  $status->setURL($this->registry->getObject('db')->sanitizeData($_POST['link_url']));
                  $status->setDescription($this->registry->getObject('db')->sanitizeData($_POST['link_description']));
              }
            }
            else
            {
                $status=new Status($this->registry,0);
            }
            $status->setProfile($user);
            $status->setPoster($loggedInUser);
            $status->setContent($this->registry->getObject('db')->sanitizeData($_POST['content']));
            $status->generateType();
            $status->save();
            //success
            $this->registry->getObject('template')->addTemplateBit( 'status_update_message', 'profile/statuses/update_confirm.tpl.php' );	
        }
        else{
            require_once(FRAMEWORK_PATH.'models/relationships.php');
            $relationships=new Relationships($this->registry);
            $network=$relationships->getNetwork($user);
            if(in_array($loggedInUser,$network)){
                 require_once(FRAMEWORK_PATH.'models/status.php');
            if(isset($_POST['status_type']) && $_POST['status_type']!='update')
            {
              if($_POST['status_type']=='image')
              {
                  require_once(FRAMEWORK_PATH.'models/imagestatus.php');
                  $status=new Imagestatus($this->registry,0);
                  $status->processImage('image_file');
              }
              elseif($_POST['status_type']=='video')
              {
                  require_once(FRAMEWORK_PATH.'models/videostatus.php');
                  $status=new Videostatus($this->registry,0);
                  $status->setVideoIdFromURL($_POST['video_url']);
              }
              elseif($_POST['status_type']=='link')
              {
                  require_once(FRAMEWORK_PATH.'models/linkstatus.php');
                  $status=new Linkstatus($this->registry,0);
                  $status->setURL($this->registry->getObject('db')->sanitizeData($_POST['link_url']));
                  $status->setDescription($this->registry->getObject('db')->sanitizeData($_POST['link_description']));
              }
            }
            else
            {
                $status=new Status($this->registry,0);
            }
            $status->setProfile($user);
            $status->setPoster($loggedInUser);
            $status->setContent($this->registry->getObject('db')->sanitizeData($_POST['content']));
            $status->generateType();
            $status->save();
            //success
            $this->registry->getObject('template')->addTemplateBit( 'status_update_message', 'profile/statuses/post_confirm.tpl.php' );	
            }
            else{
                //error
                $this->registry->getObject('template')->addTemplateBit( 'status_update_message', 'profile/statuses/error.tpl.php' );	
            }
        }
        
    
    }
        public function getFriendlyTime($time){
        $current=time();
        if($current<($time+60)){
            return $current-$time." seconds ago";
        }
        elseif($current<($time+120)){
            return "just over a minute ago";
        }
        elseif($current<($time+(60*60))){
            return round(($current-$time)/60)." minutes ago";
        }
        elseif($current<($time+(60*120))){
            return "just over an hour ago";
        }
        elseif($current<($time+(60*60*24))){
            return round(($current-$time)/(60*60))." hours ago";
        }
        else{
            return "at " . date( 'h:ia \o\n l \t\h\e jS \o\f M',$time);
        }
    }
}
?>
