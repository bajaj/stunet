<?php

class Groupscontroller
{
  private $registry;
  
  public function __construct(Registry $registry)
  {
      $this->registry=$registry;
      $urlBits=$this->registry->getObject('url')->getURLBits();
      if(isset($urlBits[1]) && $this->registry->getObject('authenticate')->isLoggedIn())
      {
          switch($urlBits[1])
          {
          case 'create':
              $this->createGroup();
              break;
          case 'edit':
              $this->editGroup(intval($urlBits[2]));
              break;
          case 'my-groups':
              $this->listMyGroups();
              break;
          case 'my-created-groups':
              $this->listMyCreatedGroups();
              break;
           case 'search':
              $this->searchGroups(false,'',0);
              break;
           case 'search-results':
              $this->searchGroups(true,isset($urlBits[2])?$urlBits[2]:'',intval(isset($urlBits[3])?$urlBits[3]:0));
              break;
          default: 
              $this->listPublicGroups(isset($urlBits[1])?$urlBits:0);
              break;
          }
      }
 else {
          $this->listPublicGroups(0);
      }
      
 }
 
 private function  createGroup()
 {
     if(isset($_POST) && count($_POST)>0)
     {
         require_once(FRAMEWORK_PATH.'models/group.php');
         $group=new Group($this->registry,0);
         $group->setName($this->registry->getObject('db')->sanitizeData($_POST['name']));
         $group->setDescription($this->registry->getObject('db')->sanitizeData($_POST['description']));
         $group->setType($this->registry->getObject('db')->sanitizeData($_POST['type']));
         $group->setCreator($this->registry->getObject('authenticate')->getUser()->getUserID());
         $group->setCollege($this->registry->getObject('db')->sanitizeData($_POST['college']));
         if( isset( $_POST['invitees'] ) && is_array( $_POST['invitees'] ) && count( $_POST['invitees'] ) > 0 )
			{// assumes invitees are added to a table using javascript, with a hidden field with name invitees[] for the ID of invitee 
				$is = array();
				foreach( $_POST['invitees'] as $i )
				{
					$is[] = intval( $i );
				}
				$group->setInvitees( $is );
			}
         $group->save();
        header('Location: '.$this->registry->getSetting('siteurl').'group/'.$group->getID());
     }
     else
     {
         $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/create.tpl.php','footer.tpl.php');
         require_once( FRAMEWORK_PATH . 'models/event.php' );
         $id=$this->registry->getObject('authenticate')->getUser()->getUserID();
	 $sql="SELECT u.ID,p.fname,p.lname FROM users u,profile p,relationships r WHERE r.accepted=1 AND
	 (r.usera={$id} OR r.userb={$id}) AND IF(r.usera={$id},u.ID=r.userb,u.ID=r.usera) AND p.ID=u.ID ORDER by p.fname" ;		
	 $cache=$this->registry->getObject('db')->cacheQuery($sql);
	 $this->registry->getObject('template')->getPage()->addTag('invitees',array('SQL',$cache));
	  }
 }
 
 private function editGroup($gid)
 {
     require_once(FRAMEWORK_PATH.'models/group.php');
     $group=new Group($this->registry,$gid);
     if($group->getCreator()==$this->registry->getObject('authenticate')->getUser()->getUserID())
     {
      if(isset($_POST) && count($_POST)>0)
     {
         
         $group->setName($this->registry->getObject('db')->sanitizeData($_POST['name']));
         $group->setDescription($this->registry->getObject('db')->sanitizeData($_POST['description']));
         $group->setType($this->registry->getObject('db')->sanitizeData($_POST['type']));
         $group->setCollege($this->registry->getObject('db')->sanitizeData($_POST['college']));
         if( isset( $_POST['invitees'] ) && is_array( $_POST['invitees'] ) && count( $_POST['invitees'] ) > 0 )
			{// assumes invitees are added to a table using javascript, with a hidden field with name invitees[] for the ID of invitee 
				$is = array();
				foreach( $_POST['invitees'] as $i )
				{
					$is[] = intval( $i );
				}
				$group->setInvitees( $is );
			}
         $group->save();
        header('Location: '.$this->registry->getSetting('siteurl').'group/'.$gid);
     }
     else
     {
         $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/edit.tpl.php','footer.tpl.php');
         $this->registry->getObject('template')->getPage()->addTag('group_ID',$group->getID());
         $this->registry->getObject('template')->getPage()->addTag('name',$group->getName());
         $this->registry->getObject('template')->getPage()->addTag('description',$group->getDescription());
         $this->registry->getObject('template')->getPage()->addTag('college',$group->getCollege());
         $script="";
         $type=($group->getType()=='Public')?0:1;
         $script="";
         $script.="<script type='text/javascript'>";
         $script.="document.getElementById('type').selectedIndex=".$type.';';
         $script.="</script>";
         $this->registry->getObject('template')->getPage()->addTag('script',$script);
         $idsql="select user from group_membership where `group` =".$gid;
         $id=$this->registry->getObject('authenticate')->getUser()->getUserID();
	 $sql="SELECT u.ID,p.fname,p.lname FROM users u,profile p,relationships r WHERE r.accepted=1 AND
	 (r.usera={$id} OR r.userb={$id}) AND IF(r.usera={$id},u.ID=r.userb,u.ID=r.usera) AND p.ID=u.ID and u.ID not in ($idsql) ORDER by p.fname" ;		
	 $cache=$this->registry->getObject('db')->cacheQuery($sql);
	 $this->registry->getObject('template')->getPage()->addTag('invitees',array('SQL',$cache));
	  }
     }
     else
     {
         $this->registry->errorPage('Access denied','Sorry, you are not allowed to view this page');
     }
 }
 
 private function listPublicGroups($offset)
 {
     $sql="select * from groups where active=1 and type <> 'private' ";
     require_once(FRAMEWORK_PATH.'lib/pagination/pagination.class.php');
     $pagination=new Pagination($this->registry);
     $pagination->setLimit(20);
     $pagination->setMethod('cache');
     $pagination->setOffset($offset);
     $pagination->setQuery($sql);
     $pagination->generatePagination();
     if($pagination->getNumRowsPage()==0)
     {
         $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/no-public.tpl.php','footer.tpl.php');
     }
     else
     {
         $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/public.tpl.php','footer.tpl.php');
         $this->registry->getObject('template')->getPage()->addTag('groups',array('SQL',$pagination->getCache()));
         $this->registry->getObject('template')->getPage()->addTag('current_page',$pagination->getCurrentPage());
         $this->registry->getObject('template')->getPage()->addTag('num_pages',$pagination->getNumPages());
         if($pagination->isFirst())
         {
             $this->registry->getObject('template')->getPage()->addTag('first','');
             $this->registry->getObject('template')->getPage()->addTag('previous','');
         }
         else
         {
             $this->registry->getObject('template')->getPage()->addTag('first',"<a href='groups/'>First Page</a>");
             $this->registry->getObject('template')->getPage()->addTag('previous',"<a href='groups/".($pagination->getCurrentPage()-2)."/'>Previous</a>");
         }
         if($pagination->isLast())
         {
             $this->registry->getObject('template')->getPage()->addTag('last','');
             $this->registry->getObject('template')->getPage()->addTag('next','');
         }
         else
         {
             $this->registry->getObject('template')->getPage()->addTag('last',"<a href='groups/".($this->getNumPages()-1)."/'>Last Page</a>");
             $this->registry->getObject('template')->getPage()->addTag('next',"<a href='groups/".($this->getCurrentPage())."/'>Next</a>");
        }
     
     }
    }
    
    private function listMyGroups()
    {
        $user=$this->registry->getObject('authenticate')->getUser()->getUserID();
        $sql="select *,if(CAST(created AS DATE)=current_date, CONCAT('Today ', date_format(created,'%h:%i %p')),if(CAST(created AS DATE)=current_date-1,CONCAT('Yesterday ', date_format(created,'%h:%i %p')),concat(date_format(created,'%d-%m-%Y'),' ',date_format(created,'%h:%i %p')))) as createdFriendly from groups where creator={$user} or ID in 
        (select m.group from group_membership m where m.user={$user} and m.approved=1)";
        $cache=$this->registry->getObject('db')->cacheQuery($sql);
        $this->registry->getObject('template')->getPage()->addTag('my-groups',array('SQL',$cache));
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/mine.tpl.php','footer.tpl.php');
    }
    
    private function listMyCreatedGroups()
    {
        $user=$this->registry->getObject('authenticate')->getUser()->getUserID();
        $sql="select *,if(CAST(created AS DATE)=current_date, CONCAT('Today ', date_format(created,'%h:%i %p')),if(CAST(created AS DATE)=current_date-1,CONCAT('Yesterday ', date_format(created,'%h:%i %p')),concat(date_format(created,'%d-%m-%Y'),' ',date_format(created,'%h:%i %p')))) as createdFriendly from groups where creator={$user}";
        $cache=$this->registry->getObject('db')->cacheQuery($sql);
        $this->registry->getObject('template')->getPage()->addTag('my-created-groups',array('SQL',$cache));
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/mine-created.tpl.php','footer.tpl.php');
    }
    
 private function searchGroups($search=true,$name='',$offset=0)
    {
        require_once(FRAMEWORK_PATH.'models/groups.php');
        $groups=new Groups($this->registry);
        if((isset($_POST) && count($_POST)>0 && isset($_POST['searchname']) && $_POST['searchname']!='')||$search==true)
        {//search results are being shown
            $name=urlencode($this->registry->getObject('db')->sanitizeData($_POST['searchname']));
            $by=$this->registry->getObject('db')->sanitizeData($_POST['searchby']);
            $pagination=$groups->searchGroups($name,$by,$offset);
        }
        else
        {//we are showing the search form, no search has yet been performed
            $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/no-results.tpl.php','footer.tpl.php');
            return;
        }
        if($pagination->getNumRowsPage()==0)
        {
            $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/invalid.tpl.php','footer.tpl.php');
        }
        else
        {
            $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','groups/search.tpl.php','footer.tpl.php');
            $this->registry->getObject('template')->getPage()->addTag('groups',array('SQL',$pagination->getCache()));
            $this->registry->getObject('template')->getPage()->addTag('encoded_name',$name);
            $this->registry->getObject('template')->getPage()->addTag('public_name',urldecode($name));
            $this->registry->getObject('template')->getPage()->addTag('num_pages',$pagination->getNumPages());
            $this->registry->getObject('template')->getPage()->addTag('current_page',$pagination->getCurrentPage());
            if($pagination->isFirst())
            {
                $this->registry->getObject('template')->getPage()->addTag('first','');
                $this->registry->getObject('template')->getPage()->addTag('previous','');
            }
            else
            {
                $this->registry->getObject('template')->getPage()->addTag('first',"<a href='groups/search-results/".$name."/'>First</a>");
                $this->registry->getObject('template')->getPage()->addTag('previous',"<a href='groups/search-results/".$name."/".($pagination->getCurrentPage()-2)."/'>Previous</a>");
            }
            if($pagination->isLast())
            {
                $this->registry->getObject('template')->getPage()->addTag('last','');
                $this->registry->getObject('template')->getPage()->addTag('next','');
            }
            else
            {
                $this->registry->getObject('template')->getPage()->addTag('last',"<a href='groups/search-results/".$name."/".($pagination->$getNumPages()-1)."/'>Last</a>");
                $this->registry->getObject('template')->getPage()->addTag('next',"<a href='groups/search-results/".$name."/".($pagination->getCurrentPage()+1)."/'>Previous</a>");
            }
        }
    }
 
 
}
?>