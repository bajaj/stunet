<?php
class registrationcontrollerextention
{
private $registry;
private $extraFields='';
private $errors=array();
private $errorLabels=array();
private $submittedValues=array();
private $sanitizedValues=array();

public function __construct(Registry $registry)
{
	$this->registry=$registry;
	$this->extraFields['student_college']=array('friendlyname'=>'College Name','table'=>'profile','field'=>'student_college','type'=>'text','required'=>true);
	$this->extraFields['student_field']=array('friendlyname'=>'Field of study','table'=>'profile','field'=>'student_field','type'=>'text','required'=>true);
	$this->extraFields['student_gender']=array('friendlyname'=>'Gender','table'=>'profile','field'=>'student_gender','type'=>'list','required'=>true,'options'=>array('male','female'));
	$this->extraFields['student_dob']=array('friendlyname'=>'Date of Birth','table'=>'profile','field'=>'student_dob','type'=>'DOB','required'=>true);
}


/*Validate the extra fields
@return true if there are no errors, else false!*/
public function checkRegistrationSubmission()
{
	$valid=true;
	foreach($this->extraFields as $field=>$data)
	{
		//if the fields are required but are not set or are empty
		if(!isset($_POST['register_'.$field])||$_POST['register_'.$field]==''&&$data['required']==true)
		{
		/*	$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
			$valid=false;
			$this->errors[]='Field '.$data['friendlyname'].' cannot be left empty';
			$this->errorLabels['register_'.$field.'_label']='error';*/
		}
		//if the field is empty but not required
		elseif($_POST['register_'.$field]=='')
		{
			$this->submittedValues['register_'.$field]='';
		}
		//if the field is not empty
		else
		{
			if($data['type']=='text')
			{
				$this->sanitizedValues['register_'.$field]=$this->registry->getObject('db')->sanitizeData($_POST['register_'.$field]);
				$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
			}
			elseif($data['type']=='int')
			{
				$this->sanitizedValues['register_'.$field]=intval($_POST['register_'.$field]);
				$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
			}
			elseif($data['type']=='list')
			{
				if(!in_array($_POST['register_'.$field],$data['options']))
				{
					$valid=false;
					$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
					$this->errors[]='Field '.$data['friendlyname'].' was not valid';
					$this->errorLabels['register_'.$field.'_label']='error';
				}
				else
				{
					$this->sanitizedValues['register_'.$field]=$_POST['register_'.$field];
					$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
				}
			}
			
			else
			{
				
				if($this->validateDOB($_POST['register_'.$field])==true || true)
				{
					$this->sanitizedValues['register_'.$field]=$this->registry->getObject('db')->sanitizeData($_POST['register_'.$field]);
					$this->submittedValues['register_'.$field]=$_POST['register_'.$field];
				}
				else
				{
					$valid=false;
					$this->submittedValues['registry_'.$field]=$_POST['register_'.$field];
					$this->errors[]='Field '.$data['friendlyname'].' is not valid';
					$this->errorLabels['register_'.$field.'_label']='error';
				}
			}
		}
	}
	if($valid==true)
	{
            
		return true;
	}
	else
    {
		return false;
	}
}

/*Check the DOB
@param String the DOB
@return bool*/
private function validateDOB($value)
{
	//Should be exactly 10 char
	if(strlen($value)!=10)
	{
		return false;
	}
	else
	{
		//should have exactly two '/'
		if(substr_count($value,'/')!=2)
		{
                    return false;
		}
		else
		{
		$date_parts=explode('/',$value);
		if($date_parts[0]<0||$date_parts[0]>31||$date_parts[1]<0||$date_parts[1]>12||$date_parts[2]<1880||$date_parts[2]>2013)
		{
			return false;
		}
		else
		return true;
		}
	}
}


/*Create our user profile, insert the user's profile into the database
@param int $uid the user id
@return bool
*/
public function processRegistration($uid)
{
	$tables=array();
	$tableData=array();
	
	//group the profile fields by table so we need to perform only one insert per table
	foreach($this->extraFields as $field=>$data)
	{
		if(!in_array($data['table'],$tables))
		{
			$tables[]=$data['table'];
			$tableData[$data['table']]=array('id'=>$uid,$data['field']=>$this->sanitizedValues['register_'.$field]);
		}
		else
		{
			$tableData[$data['table']][$data['field']]=$this->sanitizedValues[ 'register_' . $field ];
		}
	}
	foreach($tableData as $table=>$data)
	{
		$this->registry->getObject('db')->insertRecords($table,$data);
	}
	return true;
}

public function getRegistrationErrors()
{
	return $this->errors;
}

public function getExtraFields()
{
	return array_keys($this->extraFields);
}

public function getErrorLabels()
{
	return $this->errorLabels;
}

public function getRegistrationValues()
{
	return $this->submittedValues;
}
}

?>