<?php

class Streamcontroller{
    private $registry;
    
    public function __construct(Registry $registry,$directCall=false){
        $this->registry=$registry;
        if($this->registry->getObject('authenticate')->isLoggedIn()){
            $this->generateStream();
        }
        else{
            $this->registry->errorPage('Not logged in','You must be logged in to see what is happening in your network');
        }
    }
    
    private function generateStream($offset=0){
        require_once(FRAMEWORK_PATH.'models/stream.php');
        $stream=new Stream($this->registry);
        
        $stream->buildStream($this->registry->getObject('authenticate')->getUser()->getUserID(),$offset);
        if(!$stream->isEmpty()){
            $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','status/main.tpl.php','footer.tpl.php');
            $streamData=$stream->getStream();
            $IDs = $stream->getIDs();
            $cacheableIDs=array();
            foreach($IDs as $id){
                $i=array();
                $i['status_id']=$id;
                $cacheableIDs[]=$i;
            }
            $cache=$this->registry->getObject('db')->cacheData($cacheableIDs);
            
            $this->registry->getObject('template')->getPage()->addTag('stream',array('DATA',$cache));
            
            //Begin iterating through the streams
            foreach($streamData as $data){
                $dataTags=array();
                foreach($data as $tag=>$value){
                    $dataTags['status'.$tag]=$value;
                }
                
                if($data['profile']==$this->registry->getObject('authenticate')->getUser()->getUserID() && $data['poster']==$this->registry->getObject('authenticate')->getUser()->getUserID()){//updates on my profile by me
                    $this->registry->getObject('template')->addTemplateBit('stream-'.$data['ID'],'status/types/'.$data['type_reference'].'-metome.tpl.php',$dataTags);
                }
                elseif($data['profile']==$this->registry->getObject('authenticate')->getUser()->getUserID()){//updates on my profile
                    $this->registry->getObject('template')->addTemplateBit('stream-'.$data['ID'],'status/types/'.$data['type_reference'].'-onself.tpl.php',$dataTags);
                }
                elseif($data['poster']==$this->registry->getObject('authenticate')->getUser()->getUserID()){
                    $this->registry->getObject('template')->addTemplateBit('stream-'.$data['ID'],'status/types/'.$data['type_reference'].'-fromself.tpl.php',$dataTags);
                }
                elseif($data['poster']==$data['profile']){
                    $this->registry->getObject('template')->addTemplateBit('stream-'.$data['ID'],'status/types/'.$data['type_reference'].'-user.tpl.php',$dataTags);
                }
                else{
                    $this->registry->getObject('template')->addTemplateBit('stream-'.$data['ID'],'status/types/'.$data['type_reference'].'.tpl.php',$dataTags);
                }
        }
        
        //comments starts
            
          $status_ids=implode(',',$IDs);
          $start=array();
          foreach($IDs as $id){
              $start[$id]=array();
          }
          $comments=$start;
          $sql="select p.fname as commenter_fname, p.lname as commenter_lname, c.profile_post, c.comment from profile p, comments c where p.ID=c.creator
              and c.approved=1 and c.profile_post in ({$status_ids})";
              $this->registry->getObject('db')->executeQuery($sql);
              if($this->registry->getObject('db')->numRows()>0){
                  
                  while($comment=$this->registry->getObject('db')->getRows()){
                      if(in_array($comment['profile_post'],array_keys($comments))){
                          $comments[$comment['profile_post']][]=$comment;
                      }
                      else{
                          $comments[$comment['profile_post']]=array();
                          $comments[$comment['profile_post']][]=$comment;
                      }
                  }
              }
              foreach($comments as $status=>$commenta)
              {
                  $cache= $this->registry->getObject('db')->cacheData($commenta);
                  
                  $this->registry->getObject('template')->getPage()->addPPTag('comments-'.$status,array('DATA',$cache));
              }
     
    
    
        }
    else{
        $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','stream/none.tpl.php','footer.tpl.php');
    }
}

}?>
