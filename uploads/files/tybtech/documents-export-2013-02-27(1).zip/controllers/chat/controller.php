<?php

class chatcontroller{
    private $registry,$groupname;
    
    public function __construct(Registry $registry)
	{
	
	  $this->registry=$registry;
	  
	  if( $this->registry->getObject('authenticate')->isLoggedIn())
		{
	  $name=$this->registry->getObject('authenticate')->getUser()->getFname();
	  $name.=" ".$this->registry->getObject('authenticate')->getUser()->getLname();
	  
	  $this->groupname="bajaj";
	  $this->registry->getObject('template')->getPage()->addTag('username',$name);
	  $this->registry->getObject('template')->getPage()->addTag('grpname',$this->groupname);
	  
	  $this->registry->getObject('template')->buildFromTemplates('header.tpl.php','chat/view.tpl.php','footer.tpl.php');
	  $this->registry->getObject('template')->getPage()->addTag('userlist',array('SQL',$this->getusers()));
	  }
	}
	
	private function getusers()
	{
	$my_id=$this->registry->getObject('authenticate')->getUser()->getUserID();
	$sql="SELECT p.fname,p.lname FROM chat_users p,group_membership gm,groups g WHERE g.ID=gm.group AND gm.user=p.user_id AND p.user_id NOT IN(".$my_id.") AND g.name='".$this->groupname."'";
	$cache = $this->registry->getObject('db')->cacheQuery( $sql );
     return $cache;
	
	}
	
	
}	